"""Coordinator prototype: deterministic scheduling and task manifests; no paid API calls."""
import json, os
from datetime import datetime, timezone
from pathlib import Path
ROLES=('SEARCH','ANALYSIS','LOADERS','ELECTRONICS','VERIFY','PUBLISH')
BUDGET=int(os.getenv('MONTHLY_AI_BUDGET_RUB','2000'))

def create_plan(target: str)->dict:
    if not target.strip(): raise ValueError('Target required')
    tasks=[{'role':role,'target':target,'action':{'SEARCH':'collect sources','ANALYSIS':'identify MCU and memories','LOADERS':'verify OBD/Bench/Boot support','ELECTRONICS':'collect board photos and pinouts','VERIFY':'cross-check evidence','PUBLISH':'prepare draft only'}[role], 'status':'PENDING','requires_approval':role=='PUBLISH'} for role in ROLES]
    return {'target':target,'generated_at':datetime.now(timezone.utc).isoformat(),'monthly_budget_rub':BUDGET,'spent_rub':0,'tasks':tasks,'note':'No autonomous search or publication is enabled.'}
if __name__=='__main__':
    target=os.getenv('ECU_TARGET','Bosch MG1US018 (Chinese vehicles; HW unverified)')
    output=Path(os.getenv('OUTPUT_PATH','research_plan.json'))
    output.write_text(json.dumps(create_plan(target),ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'Created {output}')
