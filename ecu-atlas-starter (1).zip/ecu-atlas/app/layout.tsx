import './style.css';
export const metadata = {title:'Атлас ЭБУ',description:'Интерактивный технический атлас электронных блоков управления'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="ru"><body><header><strong>АТЛАС ЭБУ</strong><nav><a href="/">Каталог</a></nav></header><main>{children}</main><footer>Технические данные требуют проверки по точному HW/SW. Не подключайте питание по непроверенной схеме.</footer></body></html>}
