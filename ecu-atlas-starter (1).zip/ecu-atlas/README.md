# Интерактивный атлас ЭБУ

Independent greenfield project. First focus: Chinese vehicles. Full architecture foundation: Next.js 15, PostgreSQL/Prisma, Three.js, six specialist roles plus coordinator.

## Local start

1. Install Node.js 20+ and Docker Desktop.
2. `cp .env.example .env` (on Windows copy manually). Replace passwords before any deployment.
3. `docker compose up -d`
4. `npm install`
5. `npx prisma generate && npx prisma db push`
6. `npm run dev` and visit http://localhost:3000
7. `python agents/coordinator.py` creates a local research task plan.

## Verification and safety

The database starts empty intentionally: no fabricated ECU HW/SW numbers, pins, or loader compatibility. Every factual claim should have a source and review status. The 3D mesh is illustrative, not an exact ECU model. No AI API, web crawling, autonomous publication, or billing is implemented yet. The GitHub workflow generates a research plan only. Publication requires review.

## Next milestones

- Verified Chinese ECU records with cited sources.
- Authenticated admin UI and role-based approval.
- Persistent task queue and API integrations for agent roles.
- 3D models specific to verified ECU hardware.
- Deployment and CI checks.
